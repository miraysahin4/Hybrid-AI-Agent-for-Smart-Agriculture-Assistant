from flask import Flask, render_template_string, request, jsonify
import openai

openai.api_key = "sk-proj-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"


app = Flask(__name__)

html_code = '''
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Smart Agriculture Assistant</title>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCFkns5vsEi5xeio9aR5UDnwoC6K3ZWaCs&libraries=drawing,geometry&callback=initMap" async defer></script>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #0e1117;
      color: #f1f1f1;
      text-align: center;
      margin: 0;
      padding: 0;
    }
    h1 {
      color: #9cff57;
      margin-top: 15px;
    }
    #chatContainer {
      margin: 20px auto;
      width: 85%;
      background: #1c1f26;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 0 8px rgba(0,0,0,0.5);
    }
    textarea {
      width: 90%;
      border-radius: 10px;
      padding: 10px;
      font-size: 16px;
      background: #252a34;
      color: #eaeaea;
      border: 1px solid #333;
    }
    button {
      background-color: #00c853;
      border: none;
      color: white;
      padding: 10px 20px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      margin-top: 10px;
    }
    button:hover { background-color: #00b24a; }
    #response {
      margin-top: 20px;
      font-size: 17px;
      color: #f1f1f1;
      white-space: pre-line;
    }
    #mapContainer {
      width: 95%;
      margin: 20px auto;
      background-color: #1c1f26;
      border-radius: 12px;
      padding: 15px;
    }
    #map { height: 500px; width: 100%; border-radius: 10px; }
    #searchBar {
      margin-bottom: 10px;
      display: flex;
      justify-content: center;
      gap: 10px;
    }
    #searchInput {
      width: 60%;
      padding: 10px;
      border-radius: 8px;
      border: 1px solid #333;
      background-color: #252a34;
      color: white;
    }
    #info {
      margin-top: 10px;
      color: #aaffaa;
    }
    #clearButton {
      background-color: #ff1744;
    }
  </style>
</head>

<body>
  <h1>🌾 Smart Agriculture Assistant</h1>

  <!-- Tek Chatbox -->
  <div id="chatContainer">
    <label for="userInput">💬 Ask about your field:</label><br>
    <textarea id="userInput" rows="3" placeholder="Example: Should I irrigate today?"></textarea><br>
    <button onclick="sendMessage()">Send</button>
    <p id="response"></p>
  </div>

  <!-- Harita ve Arama Alanı -->
  <div id="mapContainer">
    <div id="searchBar">
      <input type="text" id="searchInput" placeholder="Enter city, district, or parcel info...">
      <button onclick="searchLocation()">Search</button>
      <button id="clearButton">Clear Map</button>
    </div>
    <div id="map"></div>
    <div id="info"></div>
  </div>

  <script>
    let map, drawingManager, allOverlays = [];
    let totalArea = 0;

    function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 39.0, lng: 35.0 },
        zoom: 6,
        mapTypeId: 'hybrid'
      });

      drawingManager = new google.maps.drawing.DrawingManager({
        drawingMode: google.maps.drawing.OverlayType.POLYGON,
        drawingControl: true,
        drawingControlOptions: {
          drawingModes: ['polygon']
        }
      });
      drawingManager.setMap(map);

      google.maps.event.addListener(drawingManager, 'overlaycomplete', function(event) {
        if (event.type === google.maps.drawing.OverlayType.POLYGON) {
          const shape = event.overlay;
          allOverlays.push(shape);
          const area = google.maps.geometry.spherical.computeArea(shape.getPath());
          const areaHa = area / 10000;
          totalArea += areaHa;
          document.getElementById('info').innerText = "🧭 Total Area: " + totalArea.toFixed(2) + " hectares";
        }
      });

      document.getElementById("clearButton").addEventListener("click", () => {
        allOverlays.forEach(o => o.setMap(null));
        allOverlays = [];
        totalArea = 0;
        document.getElementById("info").innerText = "";
      });
    }

    function searchLocation() {
      const address = document.getElementById("searchInput").value;
      if (!address.trim()) {
        alert("Please enter an address or parcel info.");
        return;
      }
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ address: address }, function(results, status) {
        if (status === "OK" && results[0]) {
          const location = results[0].geometry.location;
          map.setCenter(location);
          map.setZoom(17);
        } else {
          alert("Location not found: " + status);
        }
      });
    }

    function sendMessage() {
      const message = document.getElementById('userInput').value;
      const context = `Total field area: ${totalArea.toFixed(2)} hectares, Location: Turkey`;

      if (!message.trim()) {
        alert("Please type a question.");
        return;
      }

      fetch('/get_recommendation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, context })
      })
        .then(res => res.json())
        .then(data => {
          document.getElementById('response').innerText = data.response;
        })
        .catch(err => {
          document.getElementById('response').innerText = "Error: " + err.message;
        });
    }
  </script>
</body>
</html>
'''

@app.route('/')
def home():
    return render_template_string(html_code)

@app.route('/get_recommendation', methods=['POST'])
def get_recommendation():
    user_input = request.json['message']
    context_data = request.json.get('context', '')
    prompt = f"Tarla bilgisi: {context_data}\n\nSoru: {user_input}"

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Tarım konusunda uzman bir danışmansın."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=400
        )
        reply = response['choices'][0]['message']['content']
        return jsonify({'response': reply})
    except Exception as e:
        return jsonify({'response': f'Hata: {str(e)}'})

if __name__ == '__main__':
    app.run(debug=True)
